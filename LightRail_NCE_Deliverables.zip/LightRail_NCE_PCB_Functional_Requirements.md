# LIGHTRAIL AI NCE MOTHERBOARD
## Functional Requirements and Design Specification
**Document Version:** 1.0  
**Document Date:** July 2026  
**Status:** Final Release for Manufacturing  

---

## EXECUTIVE SUMMARY

The LightRail AI NCE (Neural Computing Engine) motherboard is a high-performance compute accelerator module designed for enterprise AI inference and training applications. This document provides complete functional requirements, electrical specifications, board dimensions, and component datasheets required for full PCB design and manufacturing implementation.

This is a production-grade motherboard that integrates proprietary neural processing capabilities with industry-standard interfaces and power delivery infrastructure.

---

## 1. BOARD SPECIFICATIONS

### 1.1 Physical Dimensions & Form Factor

| Parameter | Specification |
|-----------|---------------|
| **PCB Length** | 267 mm |
| **PCB Width** | 111 mm |
| **PCB Thickness** | 2.4 mm |
| **Form Factor** | Dual-Slot, Full-Height (FH) |
| **PCB Layers** | 10-layer (controlled impedance stackup) |
| **Mounting Standard** | PCI Express x16 Mechanical |
| **Cooling Type** | Active (dual 40mm axial fans) |
| **Operating Temperature** | 0°C to +55°C (ambient) |
| **Storage Temperature** | -40°C to +85°C |

### 1.2 Power Delivery Requirements

| Parameter | Specification |
|-----------|---------------|
| **Primary Input** | PCIe x16 connector: 75W (5V @ 15A) |
| **Auxiliary Power** | 8-pin PEX (12V @ 12.5A + 5V @ 3A) |
| **Secondary Power** | 6-pin PEX (12V @ 8.3A) optional |
| **Total System Power** | 225W typical / 275W peak |
| **Idle Power** | 15W |
| **Thermal Design Power (TDP)** | 225W |

### 1.3 Environmental & Compliance

| Standard | Requirement |
|----------|------------|
| **EMC** | FCC Part 15 Class B, CE EN 55032 |
| **Safety** | UL 60950-1, EN 60950-1 |
| **RoHS** | Fully Compliant (RoHS 3) |
| **WEEE** | Compliant |
| **PCB Material** | FR-4 (Tg ≥ 170°C), lead-free finish |

---

## 2. SYSTEM ARCHITECTURE

### 2.1 Block Diagram Structure

```
┌─────────────────────────────────────────────────────────────┐
│                   LightRail NCE Motherboard                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐         ┌──────────────┐                 │
│  │ PCIe x16     │         │ LR-GEN3-NPU  │                 │
│  │ Connector    │ ───────▶│ Neural Proc. │                 │
│  │ Input Mgmt   │         │ Unit (256 GB │                 │
│  │ + Switching  │         │  /s memory BW)                │
│  └──────────────┘         └──────────────┘                 │
│       │                          │                          │
│       │                   ┌──────▼────────┐                 │
│       │                   │ HBM3 Stack    │                 │
│       │                   │ (12x 16GB     │                 │
│       │                   │  = 192GB)     │                 │
│       │                   └───────────────┘                 │
│       │                                                      │
│  ┌────▼──────────────┐                                      │
│  │ Power Delivery    │◀─────────────────┐                   │
│  │ (12x 70A Module)  │                  │                   │
│  │ + Monitoring      │                  │                   │
│  └───────────────────┘          ┌───────┴────┐              │
│                                  │ Voltage    │              │
│  ┌───────────────────────┐       │ Monitor    │              │
│  │ Thermal Management    │◀─────│ & Sequence │              │
│  │ - 2x Fan Control PWM  │      │ Logic      │              │
│  │ - Temp Sensors (5x)   │      └────────────┘              │
│  └───────────────────────┘                                   │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ LED Control  │  │ JTAG/Debug   │  │ Status LEDs  │      │
│  │ RGB (3x)     │  │ Interface    │  │ (Power OK)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Functional Subsystems

#### 2.2.1 PCIe Interface & Input Management
- **PCIe Version:** Gen4 x16 electrical interface
- **Input Selection:** Automatic switching between PCIe and external power
- **Hot-plug Detection:** Full support for adapter insertion/removal
- **Voltage Monitoring:** Real-time PCIe rail monitoring (±3% accuracy)
- **Reverse Polarity Protection:** All input connectors protected

#### 2.2.2 Neural Processing Unit (LR-GEN3-NPU)
- **Architecture:** LightRail proprietary 256-core design
- **Memory Interface:** HBM3 Direct attached
- **Peak Compute:** 1.5 TFLOPS (FP32) / 3.0 TFLOPS (FP16) / 6.0 TFLOPS (INT8)
- **Clock Frequency:** 2.4 GHz nominal
- **Manufacturing Process:** 5nm FinFET
- **TDP:** 210W
- **Memory Bandwidth:** 256 GB/s
- **Thermal Interface:** Direct die attach (300x300mm footprint)

#### 2.2.3 Memory Subsystem
- **Memory Type:** HBM3 (High Bandwidth Memory 3)
- **Configuration:** 12x 16GB DRAM stacks = 192GB total
- **Memory Bandwidth:** 256 GB/s aggregate
- **Latency:** <100ns at rated frequency
- **Power (Memory):** 15W typical
- **ECC:** Full single-error correction (SECDED)

#### 2.2.4 Power Delivery Module (PDM)
- **Topology:** 12-phase direct PWM
- **Input Protection:** Anderson SB120 connectors (6-pin & 8-pin PEX)
- **Voltage Regulation:** 
  - Core: 0.65-1.10V @ 210A max
  - Memory: 1.2V @ 75A max
  - Auxiliary: 3.3V/5V rails
- **Cross-Regulation:** <2% core-memory voltage differential
- **Transient Response:** <50mV droop on 50A step load
- **Switching Frequency:** 300kHz
- **Efficiency:** >92% at rated load

#### 2.2.5 Monitoring & Telemetry
- **Sensors:**
  - PCIe rail voltage (via INA3221)
  - Core voltage/current (integrated)
  - Memory temperature (embedded thermistors x3)
  - Die temperature (internal die sensor)
  - Fan tachometer (x2 channels)
- **Data Interface:** I2C bus (100kHz standard mode)
- **Reporting Rate:** Every 100ms
- **Accuracy:** ±1% for voltage, ±2°C for temperature

#### 2.2.6 Thermal Management
- **Coolers:** 2x 40mm axial fans (DC 5V/12V configurable)
- **Control:** Closed-loop PWM (0-100%)
- **Thermal Sensor Points:** 5 strategic locations
- **Thermal Paste:** Arctic MX-4 (5 W/mK, -40 to +80°C)
- **Heatspreader:** Aluminum 6061-T6 (50x50x3mm, >50% coverage)
- **Fin Density:** 20 fins/inch
- **Airflow Requirement:** Minimum 20 CFM per cooler

#### 2.2.7 Debug & Control Interface
- **JTAG:** IEEE 1149.1-compliant
- **Connection:** 14-pin dual-row header
- **Clock Rate:** Up to 25 MHz
- **Logic Levels:** 1.8V (SSTL)
- **Access:** Full die scan + boundary test capability

#### 2.2.8 Visual Indicators
- **Status LEDs:** 
  - Power OK (Green, active-high)
  - Thermal warning (Yellow, >75°C core)
  - Activity (Blue, driven by internal counter at 2 Hz idle)
- **RGB Header:** 3-pin connector for system integration (WS2812B compatible)

---

## 3. ELECTRICAL SPECIFICATIONS

### 3.1 Power Rails & Distribution

| Rail | Voltage | Max Current | Protection | Notes |
|------|---------|-------------|-----------|-------|
| 12V PCIe | 12V ±5% | 12.5A | PTC Fuse 15A |Primary via PEX 8-pin |
| 5V Aux | 5V ±5% | 3.0A | PTC Fuse 5A | PCIe + PEX 6-pin |
| 3.3V | 3.3V ±5% | 2.5A | PTC Fuse 4A | Onboard LDO regulated |
| 1.8V | 1.8V ±5% | 1.5A | PTC Fuse 2A | I2C/Debug logic |
| Core (Vdd) | 0.65-1.10V | 210A | Active monitoring + OVP | Configured to 0.9V nominal |
| Memory (Vddm) | 1.2V ±3% | 75A | Integrated current-limit | HBM3 supply |

### 3.2 PCIe Interface Electrical

| Parameter | Specification |
|-----------|---------------|
| **Voltage Levels** | 3.3V SSTL |
| **TX Swing** | 400-600 mV differential |
| **RX Sensitivity** | 80 mV minimum |
| **Impedance (Diff)** | 100Ω ±10% (AC-coupled) |
| **Termination** | On-die (GPU side); PCB-side optional |
| **Pre-emphasis** | Adaptive, firmware-controlled |
| **Equalization** | FFE + DFE via IC controller |

### 3.3 Frequency Stability

| Clock Domain | Frequency | Tolerance | Jitter |
|--------------|-----------|-----------|---------|
| Core Clock | 2.4 GHz | ±0.1% | <2 ps RMS |
| Memory Clock | 2.4 GHz | ±0.1% | <3 ps RMS |
| Reference (OSC) | 27 MHz | ±50 ppm | <1 ps RMS |
| PCIe RefClk | 100 MHz | ±300 ppm | <20 ps RMS |

### 3.4 Thermal Specifications

| Parameter | Condition | Specification |
|-----------|-----------|---------------|
| **Thermal Resistance (Die→Case)** | Direct TIM | 0.15°C/W |
| **Thermal Resistance (Case→Air)** | With heatsink + fans | 0.25°C/W |
| **Junction Temp (Absolute Max)** | — | +100°C |
| **Throttle Temperature** | Automatic | 85°C (soft), 95°C (hard) |
| **Safe Operating Margin** | — | 10°C typical |

---

## 4. COMPONENT DATASHEETS & SPECIFICATIONS

### 4.1 LightRail Proprietary Neural Processing Unit

**Part Number:** LR-GEN3-NPU-5NM  
**Manufacturer:** LightRail AI (Internal)  
**Process Node:** 5nm FinFET (TSMC N5)  
**Die Size:** 300mm² (17.3 x 17.3 mm)

**Key Features:**
- 256 Processing Cores (homogeneous design)
- Dual-issued execution (2x ops/cycle)
- 512 KB L1 cache per core group (32 groups)
- 16 MB L2 unified cache
- 256-bit vector ALUs
- Fused multiply-add units (INT/FP)
- Dynamic voltage scaling (DVS) 0.65-1.10V
- Clock gating on idle cores (per-core)

**Compute Capabilities:**
- FP32: 1.5 TFLOPS @ 2.4 GHz
- FP16: 3.0 TFLOPS @ 2.4 GHz
- TF32: 1.5 TFLOPS @ 2.4 GHz
- INT8: 6.0 TOPS @ 2.4 GHz
- BF16: 3.0 TFLOPS @ 2.4 GHz

**Memory Interface:**
- HBM3 Direct PHY integration (12 stacks)
- 256 GB/s aggregate bandwidth
- Prefetch engines (256 outstanding requests)

**Power Characteristics:**
- Typical Idle: 5W (gated)
- Typical 50% Load: 110W
- Typical 100% Load: 210W
- Thermal Design Power (TDP): 210W @ 2.4 GHz

**Package:**
- BGA 3136 (23x23mm, 0.8mm pitch)
- Solder Balls: SAC305 lead-free
- Thermal Paste Interface (not soldered die)

**Reference Schematic:** [LR-GEN3-NPU Integration Guide v2.3]

---

### 4.2 HBM3 Memory Interface

**Part Number:** SK Hynix H58M16ABHX  
**Memory Type:** HBM3 Stack  
**Configuration:** 16Gb (2GB) per stack x 12 = 192GB total  
**Data Width:** 128-bit per stack (1024-bit aggregate)

**Electrical Specifications:**
- **Supply Voltage:** VDD = 1.2V ±3%
- **I/O Voltage:** VDDIO = 1.2V ±3%
- **Refresh Interval:** 64ms (1x refresh)
- **Access Time:** tAC = 50 ns (CAS latency 12)
- **Read Cycle:** tRC = 60 ns
- **Write Cycle:** tWC = 40 ns

**Package:**
- Die stacking: 8 dies per stack (256 Mbits per die)
- Micro bumps: 1,024 per stack
- Height: 11.5 mm (fully integrated)

**Interface Protocol:** JEDEC HBM3 (v1.0)
- Command interface: 32-bit channels
- Data width: 128-bit per stack
- Clocking: Source-synchronous, 2.4 GHz DDR

**ECC:** SECDED built-in (8 parity bits per 64-bit word)

**Datasheet Reference:** SK Hynix H58M16ABHX_Datasheet_Rev1.0.pdf

---

### 4.3 Power Delivery Control ICs

**Part Number:** MPS MP5949 (Primary)  
**Function:** 12-Phase PWM Controller  
**Input Voltage:** 6-24V (configured for 12V)

**Specifications:**
- Output Phases: 12 independent PWM drivers
- Switching Frequency: 300 kHz (programmable via EEPROM)
- Transient Response: <50mV on 50A step
- Efficiency (FET losses): <8% @ nominal load
- Control Loop: Dual-loop (voltage + current)
- Current Sensing: Integrated, 1mΩ sense network

**Feedback Inputs:**
- Voltage sense (Vout): precision ADC, ±1% accuracy
- Temperature input: thermistor or IC sensor
- Current monitor: per-phase telemetry

**Protection Features:**
- Overvoltage protection (OVP): 1.21V ± 2% (programmable)
- Overcurrent protection (OCP): Per-phase current limit (200A typ)
- Thermal shutdown: 150°C junction
- Undervoltage lockout (UVLO): 5.5V threshold

**Communication:**
- I2C Interface (PMBus v1.2 compatible)
- Telemetry output (voltage, current, temp)
- Status flags (over-current, over-temp, etc.)

**Package:** QFN-48 (7x7mm, 0.5mm pitch)

**Reference Schematic:** MPS MP5949 Evaluation Board Schematic

---

### 4.4 Voltage Monitoring IC

**Part Number:** Texas Instruments INA3221  
**Function:** Triple-channel current/voltage monitor

**Specifications:**
- Channels: 3 independent high-side shunt monitors
- Shunt Voltage Range: ±163.8 mV (over 60x gain range)
- Bus Voltage Range: 0 to 26V
- Precision: ±0.8% (voltage), ±0.5% (current)
- Sampling Rate: Configurable up to 8.8 kHz
- ADC Resolution: 16-bit

**Telemetry Channels (Configured):**
1. PCIe 12V rail (primary)
2. PCIe 5V rail (auxiliary)
3. HBM3 1.2V rail

**Communication:**
- I2C (400 kHz standard mode)
- Programmable alert thresholds
- Over-limit detection and masking

**Package:** TSSOP-20 (6.5x5mm)

**Datasheet:** TI INA3221 Technical Reference Manual

---

### 4.5 Fan Control PWM & Monitoring

**Part Number:** Nuvoton NCT6798D (or equivalent)  
**Function:** Multi-channel temperature monitor + PWM control

**Specifications:**
- Temperature Sensors: 5 channels (diodes)
- PWM Outputs: 2 channels (0-100% duty cycle)
- Frequency: Programmable 25 Hz - 32 kHz
- Hysteresis: Programmable temperature thresholds

**Fan Configuration:**
- Fan 1: CPU cooler primary
- Fan 2: Shroud cooler secondary
- PWM Mode: Linear or non-linear control curve

**Temperature Sensor Locations:**
1. Core die sensor (internal)
2. Inlet air temperature
3. Exhaust air temperature
4. Left-side ambient
5. Right-side ambient

**I2C Interface:** 100 kHz, isolated thermal monitoring

**Package:** QFN-48 (6.1x6.1mm)

---

### 4.6 Connector Specifications

#### PCIe x16 Edge Connector
- **Standard:** PCI Express 4.0 mechanical specification
- **Keying:** 16-lane female receptacle
- **Contact Rating:** Gold-plated, 500+ insertion cycles
- **Voltage:** 3.3V and 12V simultaneously
- **Current Capacity:** 75W via connector (designed limit)

#### Power Connectors (PEX)

**8-pin Auxiliary Power (PEX-8):**
- **Type:** Molex 5559 series (or equivalent)
- **Contact Rating:** 20A per contact
- **Configuration:** 4x 12V, 2x 5V, 2x GND
- **Mating Force:** <50 N
- **Keying:** Dual-key for orientation lock

**6-pin Auxiliary Power (PEX-6):**
- **Type:** Molex 5559 series (or equivalent)
- **Contact Rating:** 20A per contact
- **Configuration:** 2x 12V, 2x 5V, 2x GND
- **Note:** Optional; allows daisy-chain configuration

#### JTAG Debug Header
- **Type:** 2x7 dual-row .100" pitch header
- **Signaling:** 1.8V LVCMOS
- **Pinout:** Standard IEEE 1149.1
  - Pin 1-4, 6-7, 9-14: GND
  - Pin 5: VCC (1.8V)
  - Pin 8: TDO
  - Pin 10: TCK
  - Pin 11: TMS
  - Pin 12: TDI
  - Pin 13: TRST# (optional)
  - Pin 14: SRST# (optional)

#### LED Connectors
- **RGB Connector:** 3-pin JST PH 2.0mm pitch (GND, +5V, DATA)
- **Status Connectors:** Individual 2-pin screw terminals

---

## 5. MECHANICAL SPECIFICATIONS

### 5.1 Physical Layout & Mounting

**Board Dimensions:**
```
Top View:
┌──────────────────────────────────────┐
│  Shroud Assembly Mounting Points (4x)│
│                                      │
│  ┌────────────────────────────────┐ │
│  │   GPU Die (300x300mm)          │ │
│  │   + Heatspreader               │ │
│  │        (50x50mm center)        │ │
│  └────────────────────────────────┘ │
│                                      │
│  Cooler Duct Interfaces (2x)       │
│                                      │
│  PCIe Connector Mounting Edge      │
│  ◄─────────────────────────────────  │
│  ┌──────────────────────────────────┐│
│  │ Socket Assembly (FH Form Factor) ││
│  └──────────────────────────────────┘│
└──────────────────────────────────────┘

Dimensions:
- Length: 267 mm (PCIe mounting distance: 120 mm from edge)
- Width: 111 mm
- Height (with shroud): 88 mm
- Height (PCB only): 12 mm
- Offset (center to PCIe edge): 47 mm
```

**Mounting Holes:**
- 4x M3 clearance holes for shroud
- Threaded inserts for fan assembly (M2.5x4)
- Strain relief clips for power connectors

### 5.2 Thermal Interface & Cooling Path

**Die Cooling:**
1. GPU die (TIM contact)
2. Heatspreader (aluminum 50x50mm)
3. Thermal paste (Arctic MX-4, <0.5mm)
4. Fan duct attachment
5. Dual axial fans (40mm, 2500 RPM nominal)
6. Shroud exhaust guidance

**Thermal Path Resistance (Die to Ambient):**
- Die to spreader: ~0.05°C/W
- Spreader to fans: ~0.20°C/W (with paste)
- Fans to ambient: ~0.05°C/W
- **Total:** ~0.30°C/W (empirical, subject to airflow)

**Target Operating Condition:**
- Ambient: +25°C
- Max junction: +75°C (typical load)
- Margin to throttle: 10°C

---

## 6. DESIGN REQUIREMENTS & CONSTRAINTS

### 6.1 Signal Integrity Requirements

| Domain | Requirement | Implementation |
|--------|-------------|-----------------|
| **PCIe Links** | Gen4 compliance | Length-matched (±20 mils), 100Ω diff impedance |
| **Memory Bus** | HBM3 protocol | Source-sync, matched pair spacing <5 mils |
| **Power** | <1% ripple @ 100kHz | Ceramic caps near die, bulk caps distributed |
| **Clock** | <2 ps RMS jitter | Crystal oscillator, buffered distribution |
| **I2C Buses** | Standard mode operation | 10kΩ pull-ups, <50pF wire capacitance |

### 6.2 Layout & Routing Rules

1. **Core Power Plane**
   - Dedicated solid plane for Vdd core (0.9V nominal)
   - Via stitching every 500 mils along edges
   - Return path via contiguous GND plane

2. **PCIe Signal Routing**
   - Escape via 4 layers per signal
   - 100Ω differential impedance control
   - Cross-coupling guard traces (every 8 pairs)
   - Controlled delay matching ±20 mils

3. **Memory Interface**
   - Escape immediately under BGA (4-layer fan-out)
   - Matched-length differential pairs
   - Ground pour between data lines
   - 10mH common-mode inductance budget

4. **GND/Power Vias**
   - 0.3mm vias (10 mil drills)
   - Minimum 6 vias per 100 mils of current
   - Stitching vias between planes: 1 per square inch

### 6.3 Manufacturing Tolerances

| Parameter | Tolerance |
|-----------|-----------|
| **Trace Width** | ±10% |
| **Trace-to-Trace** | ±0.05mm |
| **Via Diameter** | ±0.05mm |
| **BGA Ball Placement** | ±0.05mm (Cpk >1.33) |
| **Pad-to-Edge** | ±0.10mm |
| **PCB Flatness** | <0.5mm across 267mm length |
| **Solder Mask Alignment** | ±0.05mm |

### 6.4 Testing & Validation

**In-Circuit Test (ICT) Points:**
- 50+ test points for power rails
- 24 test points for signal monitoring
- 8 JTAG boundary-scan test points
- Thermal sensor validation via I2C

**Functional Test Coverage:**
- PCIe link training verification
- Memory pattern test (march-YFFF)
- Voltage regulator load-transient test
- Fan PWM duty-cycle sweep
- Thermal sensor accuracy validation (±2°C)
- LED status indicator blink pattern

**Environmental Testing:**
- Thermal cycling: -20°C to +60°C, 10 cycles
- High-temperature operation: +55°C sustained
- Vibration: 2G @ 10-500 Hz per MIL-STD-810H

---

## 7. PRODUCTION & MANUFACTURING

### 7.1 Board Assembly Sequence

1. **Preparation:**
   - Solder paste application (stencil print, 100-150 micron thickness)
   - Component placement (automated for passives, manual for BGAs)
   - No-clean flux used throughout

2. **Reflow Soldering:**
   - Profile: Pb-free (SAC305), peak temp 250-260°C
   - Ramp rate: 2-3°C/sec rise time
   - Peak hold: 20-30 seconds
   - Cooling rate: Max 6°C/sec to 180°C

3. **Post-Reflow Inspection:**
   - Automated optical inspection (AOI)
   - X-ray inspection for solder voids (acceptance: <10% void area)
   - Thermal cycling stress test (3 cycles, -20 to +80°C)

4. **Final Assembly:**
   - Thermal interface material (TIM) application
   - Cooler assembly and torque verification (0.5-1.0 N⋅m)
   - Power connector stress testing
   - JTAG test coupon extraction

### 7.2 Bill of Materials (High-Level)

| Quantity | Component | Part Number | Manufacturer | Notes |
|----------|-----------|------------|--------------|-------|
| 1 | Main ASIC | LR-GEN3-NPU | LightRail AI | 5nm, BGA-3136 |
| 12 | HBM3 Memory | H58M16ABHX | SK Hynix | 16Gb stacks |
| 2 | PWM Controllers | MP5949 | Monolithic Power | Phase drivers |
| 1 | Voltage Monitor | INA3221 | Texas Instruments | Multi-channel |
| 1 | Fan Controller | NCT6798D | Nuvoton | Temp-based PWM |
| 2 | 40mm Fans | ~~(TBD)~~ | Delta/Noctua | DC 5V/12V |
| 2 | FETs (Core) | CSD95481RWJ | Texas Instruments | Per-phase switches |
| 1 | Oscillator | SG-531S | NDK | 27 MHz ±50 ppm |
| ~500 | Caps/Inductors | Various | Various | Decoupling network |
| ~200 | Resistors | Various | Various | Bias, telemetry, sensing |

**Total BOM Cost Target:** $1,200 - $1,500 @ 1k volume  
**Assembly Cost Target:** $300-400 @ 1k volume  
**Total Manufacturing Cost:** ~$1,500-1,900 per unit

---

## 8. FIRMWARE & CONFIGURATION

### 8.1 Initialization Sequence

1. **Power-on Reset (POR)**
   - Core voltage ramps to 0.9V
   - Memory voltage ramps to 1.2V
   - Wait 10ms for power stability
   - Release device from reset

2. **Clock Setup**
   - 27 MHz oscillator enabled
   - PLL multipliers configured (2.4 GHz target)
   - Wait for PLL lock (>100 microseconds)

3. **HBM3 Initialization**
   - JEDEC PHY calibration
   - CAS/RAS timing configuration
   - ECC enable + scrub init
   - Memory test pattern (BIST)

4. **Communication Interfaces**
   - I2C bus scan (find all PMBus devices)
   - Telemetry reporting startup
   - JTAG enable (scan chain verification)

5. **Thermal Management**
   - Fan controllers activate (linear curve)
   - Temperature threshold configuration
   - Monitor loop begins (100ms intervals)

### 8.2 Power Budget Allocation

| Component | Idle | 50% Load | 100% Load |
|-----------|------|----------|-----------|
| Core NPU | 5W | 110W | 210W |
| Memory HBM3 | 2W | 8W | 15W |
| Power Delivery | 2W | 8W | 12W |
| Monitoring + Fans | 1W | 3W | 5W |
| PCIe Logic | 0.5W | 2W | 3W |
| **Total** | **10.5W** | **131W** | **245W** |

---

## 9. VALIDATION & ACCEPTANCE CRITERIA

### 9.1 Electrical Validation

- [ ] Voltage regulation accuracy: Core ±3%, Memory ±2%
- [ ] Transient response: <50mV droop @ 50A step
- [ ] Thermal sensor accuracy: ±2°C
- [ ] PCIe link training: 16-lane Gen4 @ 16 GT/s
- [ ] HBM3 memory test: Pattern test (YFFF) zero errors

### 9.2 Thermal Validation

- [ ] Sustained load temp: <75°C @ 25°C ambient
- [ ] Fan acoustics: <35 dB(A) @ nominal load
- [ ] Thermal cycling: 10 cycles -20 to +60°C, no failures
- [ ] Heatspreader TIM performance: <0.20°C/W

### 9.3 Reliability Validation

- [ ] MTBF (predicted): >50,000 hours @ rated conditions
- [ ] ESD: IEC 61000-4-2 Level 3 (6 kV contact)
- [ ] EMC: FCC Part 15 Class B compliance
- [ ] Power cycling: 1,000 cycles (5V ramp/dwell/ramp)

---

## 10. REFERENCES & SUPPORTING DOCUMENTS

1. **LR-GEN3-NPU Datasheet:** [Internal Reference LR-GEN3-NPU-DS-v2.3.pdf]
2. **HBM3 Memory Interface Standard:** JEDEC JC-45.4 HBM3
3. **PCIe 4.0 Specification:** PCI-SIG PCI Express Base Specification r4.0
4. **Thermal Design Guide:** [LightRail Thermal Best Practices v1.0]
5. **Manufacturing Guidelines:** IPC-A-610E, IPC-7095
6. **Test Protocol:** [LightRail NCE Test Specification v1.2]

---

## APPENDIX A: POWER CONNECTOR PINOUTS

### 8-pin PEX Auxiliary Connector
```
Pin 1: +12V (Red)
Pin 2: +12V (Red)
Pin 3: +5V (Red/Yellow)
Pin 4: +5V (Red/Yellow)
Pin 5: GND (Black)
Pin 6: GND (Black)
Pin 7: GND (Black)
Pin 8: GND (Black)
```

### 6-pin PEX Secondary Connector (Optional)
```
Pin 1: +12V
Pin 2: +12V
Pin 3: +5V
Pin 4: +5V
Pin 5: GND
Pin 6: GND
```

---

## APPENDIX B: JTAG TEST CONNECTIVITY

| Pin | Signal | Direction | Voltage |
|-----|--------|-----------|---------|
| 1 | GND | — | 0V |
| 2 | GND | — | 0V |
| 3 | GND | — | 0V |
| 4 | GND | — | 0V |
| 5 | VCC | Supply | 1.8V |
| 6 | GND | — | 0V |
| 7 | GND | — | 0V |
| 8 | TDO | Out | 1.8V |
| 9 | GND | — | 0V |
| 10 | TCK | In | 1.8V |
| 11 | TMS | In | 1.8V |
| 12 | TDI | In | 1.8V |
| 13 | TRST# | In | 1.8V |
| 14 | SRST# | In | 1.8V |

---

**Document Prepared By:** LightRail AI Engineering Team  
**Authorized For Manufacturing:** [Signature Block]  
**Revision:** A (Initial Release)  
**Effective Date:** July 2026  

---

*This document is proprietary to LightRail AI and is provided exclusively to authorized manufacturing partners. Reproduction or distribution without written consent is prohibited.*
